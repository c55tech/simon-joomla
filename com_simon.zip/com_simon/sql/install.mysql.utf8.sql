-- SIMON Component Installation SQL
-- This component uses Joomla component parameters for configuration
-- No custom database tables are required

-- This file is required by Joomla's installer but contains no table creation
-- as the component stores settings in Joomla's component parameters

