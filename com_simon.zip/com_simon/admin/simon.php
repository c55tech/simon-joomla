<?php
/**
 * @package     SIMON
 * @subpackage  com_simon
 *
 * @copyright   Copyright (C) 2024 SIMON Team. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Controller\BaseController;

// Get the application
$app = Factory::getApplication();

// Execute the task
$controller = BaseController::getInstance('Simon', ['default_view' => 'dashboard']);
$controller->execute($app->input->get('task'));
$controller->redirect();

