<?php
/**
 * @package     SIMON
 * @subpackage  com_simon
 *
 * @copyright   Copyright (C) 2024 SIMON Team. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Simon\Administrator\Service\HTML;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

defined('_JEXEC') or die;

/**
 * SIMON helper class
 */
class AdministratorServiceProvider extends \Joomla\DI\ServiceProviderInterface
{
    public function register(\Joomla\DI\Container $container)
    {
        $container->registerServiceProvider(new \Joomla\Component\Simon\Administrator\Service\HTML\AdministratorServiceProvider());
    }
}
