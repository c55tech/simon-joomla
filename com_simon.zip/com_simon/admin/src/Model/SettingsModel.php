<?php
/**
 * @package     SIMON
 * @subpackage  com_simon
 *
 * @copyright   Copyright (C) 2024 SIMON Team. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Simon\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Factory;

/**
 * Settings model for SIMON component
 */
class SettingsModel extends AdminModel
{
    /**
     * Method to get the form.
     *
     * @param   array    $data      Data for the form.
     * @param   boolean  $loadData  True if the form is to load its own data (default case), false if not.
     *
     * @return  \Joomla\CMS\Form\Form|boolean  A Form object on success, false on failure
     */
    public function getForm($data = [], $loadData = true)
    {
        $form = $this->loadForm('com_simon.settings', 'settings', ['control' => 'jform', 'load_data' => $loadData]);

        if (empty($form)) {
            return false;
        }

        return $form;
    }

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return  mixed  The data for the form.
     */
    protected function loadFormData()
    {
        $app = Factory::getApplication();
        $data = $app->getUserState('com_simon.edit.settings.data', []);

        if (empty($data)) {
            $data = $this->getItem();
        }

        $this->preprocessData('com_simon.settings', $data);

        return $data;
    }

    /**
     * Method to get a single record.
     *
     * @return  mixed  Object on success, false on failure.
     */
    public function getItem($pk = null)
    {
        $item = new \stdClass();
        
        // Load from component params
        $app = Factory::getApplication();
        $params = $app->getParams('com_simon');
        
        $item->api_url = $params->get('api_url', '');
        $item->auth_key = $params->get('auth_key', '');
        $item->enable_cron = $params->get('enable_cron', 0);
        $item->cron_interval = $params->get('cron_interval', 3600);
        
        return $item;
    }

    /**
     * Method to save the form data.
     *
     * @param   array  $data  The form data.
     *
     * @return  boolean  True on success, False on error.
     */
    public function save($data)
    {
        $app = Factory::getApplication();
        $params = $app->getParams('com_simon');
        
        // Update params
        foreach ($data as $key => $value) {
            $params->set($key, $value);
        }
        
        // Save params
        $table = $this->getTable('Extension');
        $table->load(['element' => 'com_simon', 'type' => 'component']);
        $table->params = json_encode($params);
        
        if (!$table->store()) {
            $this->setError($table->getError());
            return false;
        }
        
        return true;
    }
}
