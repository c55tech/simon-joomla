<?php
/**
 * @package     SIMON
 * @subpackage  com_simon
 *
 * @copyright   Copyright (C) 2024 SIMON Team. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
?>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-body">
					<h2><?php echo Text::_('COM_SIMON_CLIENT_TITLE'); ?></h2>
					<p><?php echo Text::_('COM_SIMON_CLIENT_DESCRIPTION'); ?></p>
					
					<div class="alert alert-info">
						<?php echo Text::_('COM_SIMON_CLIENT_INFO'); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

