-- SIMON Component Installation SQL
-- Creates tables for suggestions and roadmap features

-- Suggestions table
CREATE TABLE IF NOT EXISTS `#__simon_suggestions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `priority` varchar(20) DEFAULT 'medium',
  `status` varchar(50) DEFAULT 'submitted',
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `votes` int(11) DEFAULT 0,
  `roadmap_id` int(11) DEFAULT NULL,
  `planned_date` date DEFAULT NULL,
  `completed_date` date DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `published` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_roadmap_id` (`roadmap_id`),
  KEY `idx_published` (`published`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Roadmap table
CREATE TABLE IF NOT EXISTS `#__simon_roadmap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `quarter` varchar(20) DEFAULT NULL,
  `year` int(4) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` varchar(50) DEFAULT 'planned',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `published` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_published` (`published`),
  KEY `idx_year_quarter` (`year`, `quarter`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Roadmap suggestions mapping table
CREATE TABLE IF NOT EXISTS `#__simon_roadmap_suggestions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roadmap_id` int(11) NOT NULL,
  `suggestion_id` int(11) NOT NULL,
  `order` int(11) DEFAULT 0,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_roadmap_suggestion` (`roadmap_id`, `suggestion_id`),
  KEY `idx_roadmap_id` (`roadmap_id`),
  KEY `idx_suggestion_id` (`suggestion_id`),
  CONSTRAINT `fk_roadmap_suggestions_roadmap` FOREIGN KEY (`roadmap_id`) REFERENCES `#__simon_roadmap` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_roadmap_suggestions_suggestion` FOREIGN KEY (`suggestion_id`) REFERENCES `#__simon_suggestions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

