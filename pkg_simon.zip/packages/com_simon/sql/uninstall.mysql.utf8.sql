-- SIMON Component Uninstallation SQL
-- Drops custom database tables

DROP TABLE IF EXISTS `#__simon_roadmap_suggestions`;
DROP TABLE IF EXISTS `#__simon_suggestions`;
DROP TABLE IF EXISTS `#__simon_roadmap`;

