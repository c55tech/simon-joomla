<?php
/**
 * @package     SIMON
 * @subpackage  com_simon
 *
 * @copyright   Copyright (C) 2024 SIMON Team. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Factory;
?>

<div class="simon-roadmap">
	<h2><?php echo Text::_('COM_SIMON_ROADMAP_TITLE'); ?></h2>
	
	<?php if (empty($this->items)) : ?>
		<div class="alert alert-info">
			<p><?php echo Text::_('COM_SIMON_NO_ROADMAP_ITEMS'); ?></p>
		</div>
	<?php else : ?>
		<?php foreach ($this->items as $item) : ?>
			<div class="card mb-4">
				<div class="card-header">
					<h3>
						<?php echo $this->escape($item->title); ?>
						<?php if ($item->year && $item->quarter) : ?>
							<small class="text-muted">(<?php echo $item->year . ' ' . $item->quarter; ?>)</small>
						<?php endif; ?>
					</h3>
					<span class="badge badge-<?php echo $item->status === 'completed' ? 'success' : ($item->status === 'in_progress' ? 'warning' : 'info'); ?>">
						<?php echo ucfirst(str_replace('_', ' ', $this->escape($item->status))); ?>
					</span>
				</div>
				<div class="card-body">
					<?php if ($item->description) : ?>
						<p><?php echo nl2br($this->escape($item->description)); ?></p>
					<?php endif; ?>
					
					<?php if (!empty($item->suggestions)) : ?>
						<h5><?php echo Text::_('COM_SIMON_INCLUDED_SUGGESTIONS'); ?>:</h5>
						<ul class="list-group">
							<?php foreach ($item->suggestions as $suggestion) : ?>
								<li class="list-group-item">
									<strong><?php echo $this->escape($suggestion->title); ?></strong>
									<?php if ($suggestion->description) : ?>
										<br><small class="text-muted"><?php echo $this->escape(substr($suggestion->description, 0, 150)) . (strlen($suggestion->description) > 150 ? '...' : ''); ?></small>
									<?php endif; ?>
									<br>
									<span class="badge badge-info"><?php echo ucfirst(str_replace('_', ' ', $this->escape($suggestion->status))); ?></span>
									<?php if ($suggestion->category) : ?>
										<span class="badge badge-secondary"><?php echo ucfirst($this->escape($suggestion->category)); ?></span>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
					
					<?php if ($item->start_date || $item->end_date) : ?>
						<p class="text-muted mt-3">
							<?php if ($item->start_date) : ?>
								<strong><?php echo Text::_('COM_SIMON_START_DATE'); ?>:</strong> <?php echo HTMLHelper::_('date', $item->start_date, Text::_('DATE_FORMAT_LC4')); ?>
							<?php endif; ?>
							<?php if ($item->end_date) : ?>
								<strong><?php echo Text::_('COM_SIMON_END_DATE'); ?>:</strong> <?php echo HTMLHelper::_('date', $item->end_date, Text::_('DATE_FORMAT_LC4')); ?>
							<?php endif; ?>
						</p>
					<?php endif; ?>
				</div>
			</div>
		<?php endforeach; ?>
	<?php endif; ?>
	
	<?php $user = Factory::getUser(); ?>
	<?php if (!$user->guest) : ?>
		<div class="mt-4">
			<a href="<?php echo Route::_('index.php?option=com_simon&view=suggestion&layout=submit'); ?>" class="btn btn-primary">
				<?php echo Text::_('COM_SIMON_SUBMIT_SUGGESTION'); ?>
			</a>
			<a href="<?php echo Route::_('index.php?option=com_simon&view=suggestion&layout=mysuggestions'); ?>" class="btn btn-secondary">
				<?php echo Text::_('COM_SIMON_VIEW_MY_SUGGESTIONS'); ?>
			</a>
		</div>
	<?php endif; ?>
</div>

