<?php
/**
 * @package     SIMON
 * @subpackage  com_simon
 *
 * @copyright   Copyright (C) 2024 SIMON Team. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Factory;
?>

<div class="simon-my-suggestions">
	<h2><?php echo Text::_('COM_SIMON_MY_SUGGESTIONS'); ?></h2>
	
	<div class="mb-3">
		<a href="<?php echo Route::_('index.php?option=com_simon&view=suggestion&layout=submit'); ?>" class="btn btn-primary">
			<?php echo Text::_('COM_SIMON_SUBMIT_NEW_SUGGESTION'); ?>
		</a>
	</div>
	
	<?php if (empty($this->items)) : ?>
		<div class="alert alert-info">
			<p><?php echo Text::_('COM_SIMON_NO_SUGGESTIONS'); ?></p>
		</div>
	<?php else : ?>
		<div class="table-responsive">
			<table class="table table-striped">
				<thead>
					<tr>
						<th><?php echo Text::_('COM_SIMON_SUGGESTION_TITLE'); ?></th>
						<th><?php echo Text::_('COM_SIMON_SUGGESTION_CATEGORY'); ?></th>
						<th><?php echo Text::_('COM_SIMON_SUGGESTION_STATUS'); ?></th>
						<th><?php echo Text::_('COM_SIMON_SUGGESTION_CREATED'); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($this->items as $item) : ?>
						<tr>
							<td>
								<strong><?php echo $this->escape($item->title); ?></strong>
								<?php if ($item->description) : ?>
									<br><small class="text-muted"><?php echo $this->escape(substr($item->description, 0, 100)) . (strlen($item->description) > 100 ? '...' : ''); ?></small>
								<?php endif; ?>
							</td>
							<td>
								<?php echo $this->escape($item->category ?: '-'); ?>
							</td>
							<td>
								<span class="badge badge-info">
									<?php echo ucfirst(str_replace('_', ' ', $this->escape($item->status))); ?>
								</span>
								<?php if ($item->roadmap_id) : ?>
									<br><small class="text-success"><?php echo Text::_('COM_SIMON_ON_ROADMAP'); ?></small>
								<?php endif; ?>
							</td>
							<td>
								<?php echo HTMLHelper::_('date', $item->created, Text::_('DATE_FORMAT_LC4')); ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</div>

