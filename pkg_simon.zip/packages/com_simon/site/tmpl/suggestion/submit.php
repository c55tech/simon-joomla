<?php
/**
 * @package     SIMON
 * @subpackage  com_simon
 *
 * @copyright   Copyright (C) 2024 SIMON Team. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;

HTMLHelper::_('behavior.formvalidator');
HTMLHelper::_('behavior.keepalive');
?>

<div class="simon-suggestion-submit">
	<h2><?php echo Text::_('COM_SIMON_SUBMIT_SUGGESTION'); ?></h2>
	
	<?php if (!empty($this->form)) : ?>
	<form action="<?php echo Route::_('index.php?option=com_simon&task=suggestion.submit'); ?>" method="post" name="adminForm" id="adminForm" class="form-validate">
		<div class="form-group">
			<?php echo $this->form->renderFieldset('suggestion'); ?>
		</div>
		
		<div class="form-group">
			<button type="submit" class="btn btn-primary"><?php echo Text::_('COM_SIMON_SUBMIT'); ?></button>
			<a href="<?php echo Route::_('index.php?option=com_simon&view=suggestion&layout=mysuggestions'); ?>" class="btn btn-secondary">
				<?php echo Text::_('COM_SIMON_VIEW_MY_SUGGESTIONS'); ?>
			</a>
		</div>
		
		<input type="hidden" name="task" value="suggestion.submit" />
		<?php echo HTMLHelper::_('form.token'); ?>
	</form>
	<?php else : ?>
	<div class="alert alert-danger">
		<p><?php echo Text::_('COM_SIMON_ERROR_FORM_NOT_LOADED'); ?></p>
	</div>
	<?php endif; ?>
</div>

