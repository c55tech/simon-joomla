-- SIMON Component Uninstallation SQL
-- This component uses Joomla component parameters for configuration
-- No custom database tables need to be dropped

-- This file is required by Joomla's installer but contains no table drops
-- as the component stores settings in Joomla's component parameters
-- Component parameters will be automatically removed during uninstallation

