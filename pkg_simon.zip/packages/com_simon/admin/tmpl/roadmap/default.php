<?php
/**
 * @package     SIMON
 * @subpackage  com_simon
 *
 * @copyright   Copyright (C) 2024 SIMON Team. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('formbehavior.chosen', 'select');
?>

<form action="<?php echo Route::_('index.php?option=com_simon&view=roadmap'); ?>" method="post" name="adminForm" id="adminForm">
	<div id="j-main-container" class="j-main-container">
		<?php if (empty($this->items)) : ?>
			<div class="alert alert-info">
				<span class="icon-info-circle" aria-hidden="true"></span><span class="visually-hidden"><?php echo Text::_('INFO'); ?></span>
				<?php echo Text::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
			</div>
		<?php else : ?>
			<?php foreach ($this->items as $item) : ?>
				<div class="card mb-3">
					<div class="card-header">
						<h3>
							<a href="<?php echo Route::_('index.php?option=com_simon&task=roadmap.edit&id=' . (int) $item->id); ?>">
								<?php echo $this->escape($item->title); ?>
							</a>
							<?php if ($item->year && $item->quarter) : ?>
								<small class="text-muted">(<?php echo $item->year . ' ' . $item->quarter; ?>)</small>
							<?php endif; ?>
						</h3>
						<span class="badge badge-<?php echo $item->status === 'completed' ? 'success' : ($item->status === 'in_progress' ? 'warning' : 'info'); ?>">
							<?php echo ucfirst(str_replace('_', ' ', $this->escape($item->status))); ?>
						</span>
					</div>
					<div class="card-body">
						<?php if ($item->description) : ?>
							<p><?php echo $this->escape($item->description); ?></p>
						<?php endif; ?>
						
						<?php if (!empty($item->suggestions)) : ?>
							<h5>Included Suggestions:</h5>
							<ul>
								<?php foreach ($item->suggestions as $suggestion) : ?>
									<li>
										<a href="<?php echo Route::_('index.php?option=com_simon&task=suggestion.edit&id=' . (int) $suggestion->id); ?>">
											<?php echo $this->escape($suggestion->title); ?>
										</a>
										<span class="badge badge-info"><?php echo ucfirst(str_replace('_', ' ', $this->escape($suggestion->status))); ?></span>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
						
						<?php if ($item->start_date || $item->end_date) : ?>
							<p class="text-muted">
								<?php if ($item->start_date) : ?>
									<strong>Start:</strong> <?php echo HTMLHelper::_('date', $item->start_date, Text::_('DATE_FORMAT_LC4')); ?>
								<?php endif; ?>
								<?php if ($item->end_date) : ?>
									<strong>End:</strong> <?php echo HTMLHelper::_('date', $item->end_date, Text::_('DATE_FORMAT_LC4')); ?>
								<?php endif; ?>
							</p>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>
	
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>

