<?php
/**
 * @package     SIMON
 * @subpackage  com_simon
 *
 * @copyright   Copyright (C) 2024 SIMON Team. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

HTMLHelper::_('behavior.multiselect');
HTMLHelper::_('formbehavior.chosen', 'select');
?>

<form action="<?php echo Route::_('index.php?option=com_simon&view=suggestions'); ?>" method="post" name="adminForm" id="adminForm">
	<div id="j-main-container" class="j-main-container">
		<?php echo HTMLHelper::_('bootstrap.startTabSet', 'myTab', ['active' => 'details']); ?>
		
		<?php echo HTMLHelper::_('bootstrap.addTab', 'myTab', 'details', Text::_('COM_SIMON_SUGGESTIONS_LIST')); ?>
		
		<?php if (empty($this->items)) : ?>
			<div class="alert alert-info">
				<span class="icon-info-circle" aria-hidden="true"></span><span class="visually-hidden"><?php echo Text::_('INFO'); ?></span>
				<?php echo Text::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
			</div>
		<?php else : ?>
			<table class="table table-striped" id="suggestionsList">
				<thead>
					<tr>
						<th width="1%" class="nowrap text-center">
							<?php echo HTMLHelper::_('grid.checkall'); ?>
						</th>
						<th class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_SIMON_SUGGESTION_TITLE', 'a.title', $this->listDirn, $this->listOrder); ?>
						</th>
						<th class="nowrap">
							<?php echo Text::_('COM_SIMON_SUGGESTION_CATEGORY'); ?>
						</th>
						<th class="nowrap">
							<?php echo Text::_('COM_SIMON_SUGGESTION_PRIORITY'); ?>
						</th>
						<th class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_SIMON_SUGGESTION_STATUS', 'a.status', $this->listDirn, $this->listOrder); ?>
						</th>
						<th class="nowrap">
							<?php echo Text::_('COM_SIMON_SUGGESTION_USER'); ?>
						</th>
						<th class="nowrap">
							<?php echo HTMLHelper::_('searchtools.sort', 'COM_SIMON_SUGGESTION_CREATED', 'a.created', $this->listDirn, $this->listOrder); ?>
						</th>
						<th class="nowrap text-center">
							<?php echo HTMLHelper::_('searchtools.sort', 'JSTATUS', 'a.published', $this->listDirn, $this->listOrder); ?>
						</th>
						<th class="nowrap text-center">
							<?php echo HTMLHelper::_('searchtools.sort', 'JGRID_HEADING_ID', 'a.id', $this->listDirn, $this->listOrder); ?>
						</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($this->items as $i => $item) : ?>
						<tr class="row<?php echo $i % 2; ?>">
							<td class="text-center">
								<?php echo HTMLHelper::_('grid.id', $i, $item->id, false, 'cid', 'cb', $item->title); ?>
							</td>
							<td>
								<a href="<?php echo Route::_('index.php?option=com_simon&task=suggestion.edit&id=' . (int) $item->id); ?>">
									<?php echo $this->escape($item->title); ?>
								</a>
							</td>
							<td>
								<?php echo $this->escape($item->category ?: '-'); ?>
							</td>
							<td>
								<span class="badge badge-<?php echo $item->priority === 'high' || $item->priority === 'critical' ? 'danger' : ($item->priority === 'medium' ? 'warning' : 'info'); ?>">
									<?php echo ucfirst($this->escape($item->priority)); ?>
								</span>
							</td>
							<td>
								<span class="badge badge-info">
									<?php echo ucfirst(str_replace('_', ' ', $this->escape($item->status))); ?>
								</span>
							</td>
							<td>
								<?php echo $this->escape($item->user_name); ?>
							</td>
							<td>
								<?php echo HTMLHelper::_('date', $item->created, Text::_('DATE_FORMAT_LC4')); ?>
							</td>
							<td class="text-center">
								<?php echo HTMLHelper::_('jgrid.published', $item->published, $i, 'suggestions.', true, 'cb'); ?>
							</td>
							<td class="text-center">
								<?php echo (int) $item->id; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		
		<?php echo HTMLHelper::_('bootstrap.endTab'); ?>
	</div>
	
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<?php echo HTMLHelper::_('form.token'); ?>
</form>

